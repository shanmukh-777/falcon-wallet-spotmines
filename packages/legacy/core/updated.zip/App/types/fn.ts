export type GenericFn = () => void
export type StateFn = React.Dispatch<React.SetStateAction<boolean>>
