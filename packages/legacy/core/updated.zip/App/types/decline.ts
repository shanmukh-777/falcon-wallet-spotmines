export enum DeclineType {
  ProofRequest = 'ProofRequest',
  CredentialOffer = 'CredentialOffer',
  Custom = 'Custom',
}
