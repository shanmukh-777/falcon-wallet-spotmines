export enum Role {
  me = 'me',
  them = 'them',
}
