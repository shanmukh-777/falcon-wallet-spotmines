export enum ModalUsage {
  CredentialRemove = 1,
  ContactRemove,
  ContactRemoveWithCredentials,
  CredentialOfferDecline,
  ProofRequestDecline,
  CustomNotificationDecline,
}
