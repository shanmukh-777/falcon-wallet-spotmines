export enum CredentialStatus {
  REVOKED = 0,
}
