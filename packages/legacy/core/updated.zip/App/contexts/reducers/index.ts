import * as store from './store'

export { store }
